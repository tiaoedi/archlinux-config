#!/bin/bash

updates=$(checkupdates | wc -l)

echo "$updates"

