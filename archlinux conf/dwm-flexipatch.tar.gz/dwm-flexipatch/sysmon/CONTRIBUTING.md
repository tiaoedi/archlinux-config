# Contributing

First of all thank you for taking your time to contribute.


## What to contribute

All contributions are welcome, but keep in mind that simplicity
and ease of use are the goal of this project. New features are nice,
but maybe you should open an issue to discuss it first, bug fixes are
more easily accepted. On the Roadmap section of the README I'll keep a
list of things I'd like to implement so they are good ones for a contribution.


## How to contribute

Nothing special here, fork and create a PR.
