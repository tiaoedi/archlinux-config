static void col(Monitor *m);

