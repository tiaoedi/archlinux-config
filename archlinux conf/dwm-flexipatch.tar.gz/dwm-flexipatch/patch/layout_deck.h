static void deck(Monitor *m);

