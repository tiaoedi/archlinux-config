static Client *getpointerclient(void);
