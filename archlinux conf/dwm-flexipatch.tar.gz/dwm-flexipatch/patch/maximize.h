static void maximize(int x, int y, int w, int h);
static void togglemax(const Arg *arg);
static void toggleverticalmax(const Arg *arg);
static void togglehorizontalmax(const Arg *arg);

