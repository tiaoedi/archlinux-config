static void get_vt_colors(void);
static int get_luminance(char *rgb);

