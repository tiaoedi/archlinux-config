static int width_stbutton(Bar *bar, BarArg *a);
static int draw_stbutton(Bar *bar, BarArg *a);
static int click_stbutton(Bar *bar, Arg *arg, BarArg *a);

