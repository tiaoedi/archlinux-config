#!/usr/bin/env bash

xrandr --output DVI-D-0 --off --output HDMI-0 --mode 1920x1080 --pos 0x0 --rotate normal --output DP-0 --mode 1920x1080 --pos 1920x0 --rotate normal --output DP-1 --off --output HDMI-1 --off --output None-1-1 --off

function run {
 if ! pgrep $1 ;
  then
    $@&
  fi
}

#xrandr --output HDMI2 --mode 1920x1080 &
xset r rate 300 50 &
run "variety"
run nm-applet
xfce4-power-manager &
run "blueberry-tray"
run "/usr/lib/xfce4/notifyd/xfce4-notifyd"
run "/usr/lib/polkit-gnome/polkit-gnome-authentication-agent-1"
picom -b  --config ~/.config/chadwm/picom/picom.conf &
run "numlockx on"
run "dunst"
#run "pasystray" &
#run "volumeicon" &
sxhkd -c ~/.config/chadwm/sxhkd/sxhkdrc &
xset s off &
xset -dpms &
run "xset led 3" & 
run kdeconnect-indicator &
run "dropbox"
feh --bg-fill $HOME/Imagens/wallpaper/wayf.jpg &
~/.config/chadwm/scripts/bar.sh &
while type chadwm >/dev/null; do chadwm && continue || break; done
