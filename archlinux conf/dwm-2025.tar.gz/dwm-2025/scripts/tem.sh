#!/usr/bin/env bash

city_name="Guarulhos"
api_key="5bed31ea4e60683c92c8e43bf0fd0976"


    temperature=$(curl -s "http://api.openweathermap.org/data/2.5/weather?q=${city_name}&appid=${api_key}" | jq -r '.main.temp' | awk '{print $1 - 273.15}')
    echo "Sp ${temperature}°C"
    

