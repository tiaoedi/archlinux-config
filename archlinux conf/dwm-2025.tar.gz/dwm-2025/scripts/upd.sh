#!/usr/bin/env bash

updates=$(checkupdates | wc -l)

echo "   $updates"

