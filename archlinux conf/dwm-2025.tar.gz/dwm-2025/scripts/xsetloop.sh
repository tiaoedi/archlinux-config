# Initialize
printf "$$" > ~/.cache/pidofbar
speed="0B/s" 



while true; do
_D=$(df -h | awk '{ if ($6 == "/") print $4 }')
_T=$(sed 's/000$/°C/' /sys/class/thermal/thermal_zone0/temp)
_w=$(bash ~/.config/dwm/scripts/tem.sh )
_d=$(date '+%d/%m/%y %H:%M')
_m=$(free -h | awk '/^Mem/ { print $3 }' | sed s/i//g)
_c=$(grep -o "^[^ ]*" /proc/loadavg)
_V=$(bash ~/.config/dwm/scripts/volume.sh )
_U=$(bash ~/.config/dwm/scripts/upd.sh)
  xsetroot -name " $_w | $_U |  $_T |  $_D |  $_c |  $(free -h | awk '/^Mem/ { print $3 }' | sed s/i//g) |  $(date "+%a%d %b%y %H:%M:%S") |$_V"
  sleep 2s
done &



