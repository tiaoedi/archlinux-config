#!/bin/bash

yad --width=100 --height=100 \
--center \
--fixed \
--title="Backlight" \
--no-buttons \
--timeout=10 \
--timeout-indicator=bottom \
yad \
--text="\nScroll your mouse wheel to change \n      the backlight of the monitor." \

