# ArcoLinux Hyprland

copy/paste from 

https://github.com/nawfalmrouyan/hyprland

November 2022
